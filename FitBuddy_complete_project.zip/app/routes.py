from fastapi import APIRouter, Depends, Form, HTTPException, Request, status
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from sqlalchemy import select
from sqlalchemy.orm import Session

from .config import get_settings
from .database import get_db
from .models import User
from .schemas import FeedbackRequest, GenerateResponse, UserInput
from .services import apply_feedback, create_plan, get_latest_plan, serialize_plan

router = APIRouter()
security = HTTPBasic()


def admin_auth(credentials: HTTPBasicCredentials = Depends(security)) -> None:
    settings = get_settings()
    valid = (
        credentials.username == settings.admin_username
        and credentials.password == settings.admin_password
    )
    if not valid:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid admin credentials",
            headers={"WWW-Authenticate": "Basic"},
        )


@router.get("/", response_class=HTMLResponse)
def home(request: Request):
    from .main import templates
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"request": request},
    )


@router.post("/generate-workout", response_class=HTMLResponse)
def generate_workout_form(
    request: Request,
    name: str = Form(...),
    user_id: str = Form(...),
    age: int = Form(...),
    weight: float = Form(...),
    goal: str = Form(...),
    intensity: str = Form(...),
    db: Session = Depends(get_db),
):
    from .main import templates

    try:
        data = UserInput(
            name=name,
            user_id=user_id,
            age=age,
            weight=weight,
            goal=goal,
            intensity=intensity,
        )
        user, plan, workout, nutrition = create_plan(db, data)
        return templates.TemplateResponse(
            request=request,
            name="result.html",
            context={
                "request": request,
                "user": user,
                "plan_id": plan.id,
                "workout_plan": workout,
                "nutrition": nutrition,
                "feedback_message": None,
            },
        )
    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={"request": request, "error": str(exc)},
            status_code=400,
        )


@router.post("/submit-feedback", response_class=HTMLResponse)
def submit_feedback_form(
    request: Request,
    user_id: str = Form(...),
    feedback: str = Form(...),
    db: Session = Depends(get_db),
):
    from .main import templates

    try:
        user, plan, updated, nutrition = apply_feedback(db, user_id, feedback)
        return templates.TemplateResponse(
            request=request,
            name="result.html",
            context={
                "request": request,
                "user": user,
                "plan_id": plan.id,
                "workout_plan": updated,
                "nutrition": nutrition,
                "feedback_message": "Your feedback was applied and the plan was updated.",
            },
        )
    except LookupError as exc:
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={"request": request, "error": str(exc)},
            status_code=404,
        )
    except Exception as exc:
        return templates.TemplateResponse(
            request=request,
            name="index.html",
            context={"request": request, "error": str(exc)},
            status_code=400,
        )


@router.get("/view-all-users", response_class=HTMLResponse, dependencies=[Depends(admin_auth)])
def view_all_users(request: Request, db: Session = Depends(get_db)):
    from .main import templates

    users = db.scalars(select(User).order_by(User.created_at.desc())).all()
    rows = []
    for user in users:
        latest = user.plans[0] if user.plans else None
        rows.append({"user": user, "plan": latest, "serialized": serialize_plan(latest) if latest else None})

    return templates.TemplateResponse(
        request=request,
        name="all_users.html",
        context={"request": request, "rows": rows},
    )


@router.get("/health")
def health():
    return {"status": "ok"}


@router.post("/api/generate-workout", response_model=GenerateResponse)
def generate_workout_api(data: UserInput, db: Session = Depends(get_db)):
    try:
        user, plan, workout, nutrition = create_plan(db, data)
        return GenerateResponse(
            user_id=user.user_id,
            name=user.name,
            goal=user.goal,
            intensity=user.intensity,
            workout_plan=workout,
            nutrition=nutrition,
            plan_id=plan.id,
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/api/submit-feedback")
def submit_feedback_api(data: FeedbackRequest, db: Session = Depends(get_db)):
    try:
        user, plan, updated, nutrition = apply_feedback(db, data.user_id, data.feedback)
        return {
            "user_id": user.user_id,
            "feedback": data.feedback,
            "updated_plan": updated,
            "nutrition": nutrition,
            "plan_id": plan.id,
        }
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.get("/api/users", dependencies=[Depends(admin_auth)])
def users_api(db: Session = Depends(get_db)):
    users = db.scalars(select(User).order_by(User.created_at.desc())).all()
    result = []
    for user in users:
        latest = user.plans[0] if user.plans else None
        result.append({
            "id": user.id,
            "user_id": user.user_id,
            "name": user.name,
            "age": user.age,
            "weight": user.weight,
            "goal": user.goal,
            "intensity": user.intensity,
            "latest_plan_id": latest.id if latest else None,
            "has_updated_plan": bool(latest and latest.updated_plan),
        })
    return result


@router.get("/api/users/{user_id}")
def get_user_plan(user_id: str, db: Session = Depends(get_db)):
    found = get_latest_plan(db, user_id)
    if not found:
        raise HTTPException(status_code=404, detail="User or plan not found")
    user, plan = found
    return {
        "user": {
            "user_id": user.user_id,
            "name": user.name,
            "age": user.age,
            "weight": user.weight,
            "goal": user.goal,
            "intensity": user.intensity,
        },
        "plan_id": plan.id,
        **serialize_plan(plan),
    }
