from .ai_utils import get_gemini_client
from .config import get_settings
from .schemas import NutritionTip, UserInput


def _mock_tip(user: UserInput) -> NutritionTip:
    return NutritionTip(
        tip="Build regular meals around varied foods and include a protein source where appropriate.",
        recovery_note="Hydrate regularly, sleep well, and allow recovery between harder sessions.",
    )


def generate_nutrition_tip_with_flash(user: UserInput) -> NutritionTip:
    settings = get_settings()
    if settings.mock_ai:
        return _mock_tip(user)

    prompt = f"""
Give one concise nutrition/recovery tip for a general fitness user.

Goal: {user.goal}
Intensity: {user.intensity}
Age: {user.age}

Avoid calorie targets, crash diets, supplement prescriptions, or medical claims.
Focus on balanced eating, hydration, recovery, and sustainable habits.
Return a concise tip and a concise recovery note.
"""

    client = get_gemini_client()
    response = client.models.generate_content(
        model=settings.fast_model,
        contents=prompt,
        config={
            "response_mime_type": "application/json",
            "response_schema": NutritionTip,
        },
    )
    if getattr(response, "parsed", None):
        return response.parsed
    return NutritionTip.model_validate_json(response.text)
