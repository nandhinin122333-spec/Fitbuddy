from google import genai

from .config import get_settings

_client: genai.Client | None = None


def get_gemini_client() -> genai.Client:
    global _client
    settings = get_settings()

    if _client is None:
        if not settings.gemini_api_key:
            raise RuntimeError(
                "GEMINI_API_KEY is not configured. Add it to your .env file or set MOCK_AI=true."
            )
        _client = genai.Client(api_key=settings.gemini_api_key)

    return _client
