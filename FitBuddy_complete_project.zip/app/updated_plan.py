from .ai_utils import get_gemini_client
from .config import get_settings
from .gemini_generator import SYSTEM_INSTRUCTION
from .schemas import NutritionTip, UserInput, WorkoutPlan


def update_workout_plan(
    user: UserInput,
    original_plan: WorkoutPlan,
    feedback: str,
) -> WorkoutPlan:
    settings = get_settings()

    if settings.mock_ai:
        # Keep the demo deterministic while visibly reflecting the feedback.
        updated = original_plan.model_copy(deep=True)
        updated.title = f"{original_plan.title} – Updated"
        updated.safety_note = (
            f"{original_plan.safety_note} Feedback applied: {feedback.strip()[:180]}"
        )
        return updated

    prompt = f"""
Revise this 7-day fitness plan using the user's feedback.

User:
- Goal: {user.goal}
- Intensity: {user.intensity}

Original plan:
{original_plan.model_dump_json(indent=2)}

Feedback:
{feedback}

Keep exactly 7 days and the same structured fields.
Apply reasonable changes without increasing risk.
Do not prescribe medical treatment or extreme exercise.
"""

    client = get_gemini_client()
    response = client.models.generate_content(
        model=settings.workout_model,
        contents=prompt,
        config={
            "system_instruction": SYSTEM_INSTRUCTION,
            "response_mime_type": "application/json",
            "response_schema": WorkoutPlan,
        },
    )
    if getattr(response, "parsed", None):
        return response.parsed
    return WorkoutPlan.model_validate_json(response.text)
