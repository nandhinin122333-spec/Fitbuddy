from typing import Literal
from pydantic import BaseModel, Field, ConfigDict

Goal = Literal["weight loss", "muscle gain", "general wellness", "flexibility", "endurance"]
Intensity = Literal["low", "medium", "high"]


class UserInput(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    user_id: str = Field(min_length=2, max_length=80, pattern=r"^[A-Za-z0-9_-]+$")
    age: int = Field(ge=13, le=100)
    weight: float = Field(gt=20, lt=500)
    goal: Goal
    intensity: Intensity


class FeedbackRequest(BaseModel):
    user_id: str = Field(min_length=2, max_length=80)
    feedback: str = Field(min_length=3, max_length=2000)


class Exercise(BaseModel):
    name: str
    sets: str
    reps_or_duration: str
    rest: str


class DayPlan(BaseModel):
    day: str
    focus: str
    warm_up: str
    exercises: list[Exercise] = Field(min_length=1, max_length=8)
    cooldown: str


class WorkoutPlan(BaseModel):
    title: str
    safety_note: str
    days: list[DayPlan] = Field(min_length=7, max_length=7)


class NutritionTip(BaseModel):
    tip: str
    recovery_note: str


class GenerateResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    user_id: str
    name: str
    goal: str
    intensity: str
    workout_plan: WorkoutPlan
    nutrition: NutritionTip
    plan_id: int


class FeedbackResponse(BaseModel):
    user_id: str
    feedback: str
    updated_plan: WorkoutPlan
    nutrition: NutritionTip
    plan_id: int
