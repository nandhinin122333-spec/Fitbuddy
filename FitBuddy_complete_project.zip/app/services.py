import json
from sqlalchemy import select
from sqlalchemy.orm import Session

from .gemini_flash_generator import generate_nutrition_tip_with_flash
from .gemini_generator import generate_workout_gemini
from .models import Plan, User
from .schemas import UserInput, WorkoutPlan, NutritionTip
from .updated_plan import update_workout_plan


def get_or_create_user(db: Session, data: UserInput) -> User:
    user = db.scalar(select(User).where(User.user_id == data.user_id))
    if user:
        user.name = data.name
        user.age = data.age
        user.weight = data.weight
        user.goal = data.goal
        user.intensity = data.intensity
    else:
        user = User(
            user_id=data.user_id,
            name=data.name,
            age=data.age,
            weight=data.weight,
            goal=data.goal,
            intensity=data.intensity,
        )
        db.add(user)
        db.flush()
    return user


def create_plan(db: Session, data: UserInput) -> tuple[User, Plan, WorkoutPlan, NutritionTip]:
    user = get_or_create_user(db, data)
    workout = generate_workout_gemini(data)
    nutrition = generate_nutrition_tip_with_flash(data)

    plan = Plan(
        user=user,
        original_plan=workout.model_dump_json(),
        nutrition_tip=nutrition.model_dump_json(),
    )
    db.add(plan)
    db.commit()
    db.refresh(plan)
    return user, plan, workout, nutrition


def get_latest_plan(db: Session, user_id: str) -> tuple[User, Plan] | None:
    user = db.scalar(select(User).where(User.user_id == user_id))
    if not user:
        return None
    plan = db.scalar(
        select(Plan)
        .where(Plan.user_id_fk == user.id)
        .order_by(Plan.created_at.desc())
    )
    if not plan:
        return None
    return user, plan


def apply_feedback(
    db: Session,
    user_id: str,
    feedback: str,
) -> tuple[User, Plan, WorkoutPlan, NutritionTip]:
    found = get_latest_plan(db, user_id)
    if not found:
        raise LookupError("No plan exists for this user ID.")

    user, plan = found
    user_input = UserInput(
        name=user.name,
        user_id=user.user_id,
        age=user.age,
        weight=user.weight,
        goal=user.goal,
        intensity=user.intensity,
    )
    original = WorkoutPlan.model_validate_json(plan.original_plan)
    updated = update_workout_plan(user_input, original, feedback)
    nutrition = generate_nutrition_tip_with_flash(user_input)

    plan.updated_plan = updated.model_dump_json()
    plan.feedback = feedback
    plan.nutrition_tip = nutrition.model_dump_json()
    db.commit()
    db.refresh(plan)
    return user, plan, updated, nutrition


def serialize_plan(plan: Plan) -> dict:
    return {
        "original_plan": json.loads(plan.original_plan),
        "updated_plan": json.loads(plan.updated_plan) if plan.updated_plan else None,
        "nutrition": json.loads(plan.nutrition_tip),
        "feedback": plan.feedback,
    }
