from .ai_utils import get_gemini_client
from .config import get_settings
from .schemas import UserInput, WorkoutPlan


SYSTEM_INSTRUCTION = """
You are FitBuddy, a cautious fitness-planning assistant.
Create general wellness-oriented exercise plans, not medical treatment.
Do not diagnose, prescribe medication, encourage dangerous challenges, extreme dieting,
starvation, dehydration, or unsafe training volume. Avoid claims that a plan guarantees
weight loss or muscle gain. Include a short safety note telling the user to stop if they
feel pain, dizziness, faintness, or other concerning symptoms and to seek qualified help
when appropriate.
"""


def _mock_plan(user: UserInput) -> WorkoutPlan:
    focus_by_goal = {
        "weight loss": "Cardio + full body",
        "muscle gain": "Strength fundamentals",
        "general wellness": "Balanced full body",
        "flexibility": "Mobility + flexibility",
        "endurance": "Cardio endurance",
    }
    focus = focus_by_goal[user.goal]
    days = []
    for i in range(1, 8):
        if i in (3, 7):
            day_focus = "Recovery / light mobility"
            exercises = [
                {"name": "Easy walking", "sets": "1", "reps_or_duration": "15–20 min", "rest": "As needed"},
                {"name": "Gentle mobility", "sets": "1", "reps_or_duration": "8–10 min", "rest": "As needed"},
            ]
        else:
            day_focus = focus
            exercises = [
                {"name": "Bodyweight squat", "sets": "2–3", "reps_or_duration": "8–12 reps", "rest": "60–90 sec"},
                {"name": "Incline push-up", "sets": "2–3", "reps_or_duration": "6–12 reps", "rest": "60–90 sec"},
                {"name": "Glute bridge", "sets": "2–3", "reps_or_duration": "10–15 reps", "rest": "60 sec"},
            ]
        days.append({
            "day": f"Day {i}",
            "focus": day_focus,
            "warm_up": "5–10 min of easy movement and gentle mobility.",
            "exercises": exercises,
            "cooldown": "5–10 min of easy movement and comfortable stretching.",
        })
    return WorkoutPlan(
        title=f"7-Day {user.goal.title()} Plan",
        safety_note="Start gradually, use comfortable technique, and stop for pain, dizziness, or unusual symptoms.",
        days=days,
    )


def generate_workout_gemini(user: UserInput) -> WorkoutPlan:
    settings = get_settings()
    if settings.mock_ai:
        return _mock_plan(user)

    prompt = f"""
Create a structured 7-day general fitness plan.

User:
- Name: {user.name}
- Age: {user.age}
- Weight: {user.weight} kg
- Goal: {user.goal}
- Preferred intensity: {user.intensity}

Requirements:
- Exactly 7 days.
- Each day must have a focus, warm-up, exercises, and cooldown.
- Each exercise must include name, sets, reps_or_duration, and rest.
- Use practical, moderate progression.
- Include recovery days where appropriate.
- Do not prescribe medical treatment.
- Do not encourage extreme exercise or restrictive eating.
"""

    client = get_gemini_client()
    response = client.models.generate_content(
        model=settings.workout_model,
        contents=prompt,
        config={
            "system_instruction": SYSTEM_INSTRUCTION,
            "response_mime_type": "application/json",
            "response_schema": WorkoutPlan,
        },
    )
    if getattr(response, "parsed", None):
        return response.parsed
    return WorkoutPlan.model_validate_json(response.text)
