# FitBuddy – AI Fitness Plan Generator

FitBuddy is a FastAPI web application that uses Google Gemini to generate a structured 7-day general fitness plan, provide a concise nutrition/recovery tip, and update the plan from user feedback.

## Architecture

- **Frontend:** HTML + Jinja2 + CSS
- **Backend:** FastAPI
- **AI:** Google GenAI Python SDK
- **Database:** SQLite + SQLAlchemy
- **Validation:** Pydantic
- **Testing:** pytest + FastAPI TestClient

The original project documentation specified Gemini 1.5 Pro and Gemini Flash. Those older model choices are not used in this implementation because Google has moved to newer Gemini model families. The project therefore uses configurable current models:
- Workout/update: `gemini-3.1-pro-preview`
- Fast nutrition/recovery: `gemini-3.8-flash`

Change these through `.env` if your account exposes different models.

## Project structure

```text
FitBuddy/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── database.py
│   ├── models.py
│   ├── schemas.py
│   ├── ai_utils.py
│   ├── gemini_generator.py
│   ├── gemini_flash_generator.py
│   ├── updated_plan.py
│   ├── services.py
│   └── routes.py
├── templates/
│   ├── index.html
│   ├── result.html
│   └── all_users.html
├── static/
│   ├── style.css
│   └── images/
├── tests/
│   ├── __init__.py
│   └── test_app.py
├── .env.example
├── .gitignore
├── requirements.txt
└── README.md
```

## 1. VS Code setup

Install:
- Python 3.11 or newer
- VS Code
- VS Code Python extension

Open the `FitBuddy` folder in VS Code.

### Windows PowerShell

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 2. Configure Gemini

Copy `.env.example` to `.env`.

Set:

```env
GEMINI_API_KEY=your_key_here
WORKOUT_MODEL=gemini-3.1-pro-preview
FAST_MODEL=gemini-3.8-flash
ADMIN_USERNAME=admin
ADMIN_PASSWORD=choose_a_password
MOCK_AI=false
```

Never commit `.env`.

If you only want to test the application without calling Gemini:

```env
MOCK_AI=true
```

The mock mode produces deterministic demo plans, so the database and frontend can be tested without an API key.

## 3. Start the application

```bash
uvicorn app.main:app --reload
```

Open:

- Home: http://127.0.0.1:8000
- Swagger/OpenAPI: http://127.0.0.1:8000/docs
- ReDoc: http://127.0.0.1:8000/redoc
- Health: http://127.0.0.1:8000/health
- Admin: http://127.0.0.1:8000/view-all-users

The admin page uses HTTP Basic Authentication with `ADMIN_USERNAME` and `ADMIN_PASSWORD`.

## 4. Test the application

Run:

```bash
pytest -q
```

For a clean demo without Gemini:

```bash
# .env
MOCK_AI=true
pytest -q
uvicorn app.main:app --reload
```

## 5. API examples

### Generate a plan

POST `/api/generate-workout`

```json
{
  "name": "Demo User",
  "user_id": "FB001",
  "age": 21,
  "weight": 65,
  "goal": "general wellness",
  "intensity": "medium"
}
```

### Submit feedback

POST `/api/submit-feedback`

```json
{
  "user_id": "FB001",
  "feedback": "Please add more recovery and simpler sessions."
}
```

### Read a user's latest plan

GET `/api/users/FB001`

### List users

GET `/api/users`

This endpoint requires HTTP Basic Authentication.

## Notes about AI output

FitBuddy is designed as a general wellness planning demo. AI-generated plans should be reviewed by an appropriately qualified professional when the user's circumstances require it. The prompts explicitly avoid medical diagnosis, extreme exercise, starvation/restrictive dieting, and unsafe challenges.

## Troubleshooting

### `GEMINI_API_KEY is not configured`

Either put the key in `.env` or set:

```env
MOCK_AI=true
```

### Gemini model error

Set `WORKOUT_MODEL` and `FAST_MODEL` to model IDs currently available to your Gemini API project. Model availability can vary by account and API access.

### Port already in use

Run:

```bash
uvicorn app.main:app --reload --port 8001
```

Then open http://127.0.0.1:8001.

## Database

SQLite is automatically created as `fitbuddy.db` when the application starts. It is intentionally ignored by Git.

## Main application flow

1. User submits name, user ID, age, weight, goal, and intensity.
2. FastAPI validates the input with Pydantic.
3. Gemini generates a structured 7-day plan.
4. Gemini generates a concise nutrition/recovery tip.
5. SQLAlchemy stores user and plan data in SQLite.
6. Jinja2 renders the result.
7. User submits feedback.
8. Gemini revises the plan.
9. The revised plan, feedback, and latest nutrition/recovery tip are saved.
10. Admin can inspect registered users and latest plan status.
