import os

os.environ["MOCK_AI"] = "true"
os.environ["DATABASE_URL"] = "sqlite:///./test_fitbuddy.db"

from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"


def test_home():
    response = client.get("/")
    assert response.status_code == 200
    assert "FitBuddy" in response.text


def test_generate_api():
    payload = {
        "name": "Test User",
        "user_id": "TEST001",
        "age": 21,
        "weight": 65,
        "goal": "general wellness",
        "intensity": "medium",
    }
    response = client.post("/api/generate-workout", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["plan_id"] > 0
    assert len(data["workout_plan"]["days"]) == 7


def test_feedback_api():
    payload = {
        "user_id": "TEST001",
        "feedback": "Add more recovery and simpler sessions.",
    }
    response = client.post("/api/submit-feedback", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["updated_plan"]["title"].endswith("Updated")


def test_missing_feedback_user():
    response = client.post(
        "/api/submit-feedback",
        json={"user_id": "DOES_NOT_EXIST", "feedback": "More recovery"},
    )
    assert response.status_code == 404
